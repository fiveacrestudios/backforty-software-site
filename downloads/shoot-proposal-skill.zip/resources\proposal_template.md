# Proposal shape

Follow this structure for the proposal document. Replace every bracketed field; remove sections that genuinely don't apply to this shoot type rather than leaving them blank.

---

**Proposal for [Client Name]**
[Studio/Photographer Name] · [Date Prepared]

## Overview
One short paragraph: the shoot, the date, why it's a good fit. Warm, not salesy.

## Scope of Work
- Shoot type: [type]
- Date(s): [date(s)] (backup/rain date: [date or "n/a"])
- Location: [location]
- Duration: [hours/coverage window]

## Deliverables
- [# edited photos / video length / format]
- Turnaround: [X business days from shoot date]

## Investment
| Item | Amount |
|---|---|
| [Shoot fee] | [$] |
| [Editing fee, if separate] | [$] |
| [Travel fee, if applicable] | [$] |
| **Total** | **[$]** |

Payment terms: [deposit amount/% due at booking], balance of [$] due [date/trigger].

## Usage Rights
Plain-language summary of how the client can use the deliverables (personal, commercial, social, print, exclusivity) — full terms live in the contract.

## Next Steps
How to book: sign the attached contract and submit the deposit by [date] to hold this date.
