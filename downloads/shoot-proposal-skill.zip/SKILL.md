---
name: shoot-proposal
description: Generate a client-ready photography/videography proposal and matching contract from shoot details (client, shoot type, date, deliverables, price, usage rights). Use when the user needs to send a quote or proposal to a new photo/video client, draft a shoot contract, or turn shoot details into a signable agreement. Triggers on "proposal", "quote", "contract", "scope of work", "photography agreement", "shoot agreement", "client contract".
---

# Shoot Proposal & Contract Generator

Turns a photo/video shoot's details into two client-ready documents: a **proposal** (the sales-facing quote) and a **contract** (the signable agreement). Built for solo and small-studio photographers/videographers who need this to move fast — a lead that waits three days for paperwork is a lead that books someone else.

## Required inputs

**Ask one item at a time, in that order.** Don't dump the full checklist in one message — send one question, wait for the client's/user's answer, then ask the next. If several items are already given up front (e.g. a pasted client email), skip straight past those and only ask, one at a time, for what's still missing.

Ask for whatever isn't already given. Don't invent pricing, dates, or legal terms — if something is genuinely unknown, write `[TBD — confirm with client]` in that spot rather than guessing.

- **Client name** (and company name, if commercial work)
- **Shoot type** — portrait, wedding, commercial/brand, event, real estate, or other (ask if ambiguous; this changes which defaults below apply)
- **Date(s)** and whether there's a rain/backup date already discussed
- **Location** — studio, client site, outdoor/on-location (flag if outdoor: weather clause matters more)
- **Duration** — hours booked or "until X shots/scenes are covered"
- **Deliverables** — number of edited photos, video length/count, format (raw + edited, highlight reel, etc.), turnaround time in business days
- **Price** — flat fee or itemized (shoot fee, editing fee, travel fee, add-ons)
- **Payment terms** — deposit amount or %, balance due date, accepted payment methods
- **Usage/licensing** — personal use only, commercial use, social media only, exclusivity, print rights, term/duration of license
- **Model release** — whether people other than the primary client will be identifiable in deliverables. Always ask explicitly, for every shoot type, including family/portrait. Never assume or infer consent from context (e.g. "it's a family portrait, so the kids are covered") — get it confirmed, or exclude that person from usable deliverables.

## Shoot-type defaults (use only to fill gaps, always flag as assumptions)

- **Wedding** — weather/rescheduling clause matters most; deposit typically 25–50%, non-refundable past a cutoff; usage is personal/family by default.
- **Commercial/brand** — usage rights are the crux of the negotiation (term, exclusivity, media channels); price per-project or day-rate; payment often 50/50 deposit/delivery.
- **Portrait (family/individual)** — simplest terms; personal usage only unless stated; smaller deposit or full payment at booking.
- **Event** (corporate, party, etc.) — usually a flat day-rate; usage often extends to the client's marketing use, confirm this explicitly.
- **Real estate** — fast turnaround expectations (24–48 hrs common); usage is the listing agent/agency's marketing use; often no deposit, invoiced after delivery.

If the shoot is outdoor/on-location for any type, always include the weather/rescheduling clause regardless of preset.

## What to produce

Two documents, following the shape in `resources/proposal_template.md` and `resources/contract_template.md`:

1. **Proposal** — client-facing, warm and concise, sells the shoot: overview, scope of work, deliverables, timeline, investment (price breakdown), next steps/how to book. No legal density here — that's what the contract is for.
2. **Contract** — the signable agreement, mirroring the proposal's scope exactly (numbers must match between the two documents). Must always include:
   - Parties and effective date
   - Scope of work (mirrors proposal)
   - Payment schedule, including late-fee terms (default: $5/day, starting the day after the balance due date, until paid — override if the user specifies different terms)
   - Cancellation / rescheduling policy (default: Photographer always offers to reschedule first, whether the cancellation is weather-driven or client-initiated; deposit is forfeited only if Client declines to reschedule — override if the user specifies different terms)
   - Copyright ownership — photographer/videographer retains copyright by default; the contract grants the client a **license** to use the deliverables per the usage terms gathered above, not a copyright transfer, unless the client has explicitly negotiated a buyout (flag this as a notable, higher-price term if it comes up)
   - Model release consent language, scoped to what was gathered above
   - Limitation of liability
   - Force majeure
   - Signature blocks for both parties

## Tone and guardrails

- Professional, warm, plain language — no dense legalese for its own sake, but the contract terms must be specific and real, not vague placeholders.
- Always close the contract with a one-line disclaimer that this is a template, not a substitute for a lawyer's review, especially for high-value or unusually complex bookings.
- Keep the two documents consistent with each other — if the user changes a number in one, offer to update the other.
- Never assume or infer model-release consent, regardless of shoot type — always ask explicitly and record exactly who it covers.
- This skill is written for general use across photo/video businesses, not hard-coded to any single studio's defaults. The late-fee and cancellation defaults above are this studio's actual policy, shipped as the default — a different user of this skill can override them by stating their own terms.
