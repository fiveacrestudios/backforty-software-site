# Contract shape

Follow this structure for the contract. Numbers here must match the proposal exactly. Replace every bracketed field.

---

**Photography/Videography Services Agreement**

This agreement is entered into on [effective date] between [Studio/Photographer Legal Name] ("Photographer") and [Client Name] ("Client").

## 1. Scope of Work
[Mirror the proposal's scope of work exactly — shoot type, date(s), location, duration.]

## 2. Deliverables
[Mirror the proposal's deliverables exactly, including turnaround time.]

## 3. Payment
Total fee: [$]. Deposit of [$/%] due upon signing to secure the date. Balance of [$] due [date/trigger]. Late payments incur a $5/day late fee, beginning the day after the balance due date, until paid in full.

## 4. Cancellation and Rescheduling
If the shoot cannot proceed as scheduled — whether due to weather/conditions outside either party's control, or at Client's request — Photographer will offer to reschedule to a mutually agreed date at no additional cost. If Client does not want to reschedule: [if a deposit was collected] the deposit is forfeited; [if no deposit was collected — full payment due at/after the shoot] the session is cancelled with no fee owed by either party. Cancellation by Photographer will result in a full refund of any amount paid and reasonable assistance finding a replacement.

## 5. Copyright and Usage License
Photographer retains copyright to all images/footage produced under this agreement. Client is granted a license to use the deliverables as follows: [usage scope — personal/commercial/social/print, term, exclusivity]. Any use beyond this scope requires separate written permission from Photographer. [If a full copyright buyout was negotiated instead of a license, state that explicitly here and reflect it in the price above.]

## 6. Model Release
Client confirms consent, obtained from every identifiable person appearing in the deliverables (including on Client's behalf for any minors in Client's care), for use of their likeness as described in Section 5. [State explicitly who this covers — never assume; if consent for someone in frame has not actually been confirmed, that person's likeness must be excluded from usable deliverables or consent must be obtained before delivery.]

## 7. Limitation of Liability
Photographer's liability under this agreement is limited to the total fees paid by Client. Photographer is not liable for indirect or consequential damages.

## 8. Force Majeure
Neither party is liable for delay or failure to perform due to causes beyond reasonable control (illness, accident, natural disaster, etc.), beyond the weather provision in Section 4.

## 9. Signatures

Photographer: ______________________ Date: _______

Client: ______________________ Date: _______

---
*This document is a template and does not constitute legal advice. For high-value or unusually complex bookings, have it reviewed by a licensed attorney before use.*
